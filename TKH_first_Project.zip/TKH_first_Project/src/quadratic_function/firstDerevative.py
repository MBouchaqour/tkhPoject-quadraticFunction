#checking for derivative of function ax^2+bx+c at the point x
def get_derivative(a,b,c,x):
  try:
    return 2*a*x+b
  except:
    return "something went wrong"
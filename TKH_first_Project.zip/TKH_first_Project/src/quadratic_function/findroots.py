# solve the equation ax^2+bx+c=0
import math
def solve_eq(a,b,c):
  try:
    delta=math.pow(b,2)-(4*a*c)
    message="No real solution"
    result=""
    if delta<0:
      message="Check for imaginary solution"
    elif delta==0:
      message="There is one solution"
      result=-b/(2*a)
    else:
      message="there is two solution"
      solution1=(-b+math.sqrt(delta))/(2*a)
      solution2=(-b-math.sqrt(delta))/(2*a)
      result=(solution1,solution2)
    return message,result
  except:
    return "OPPS! something went wrong"

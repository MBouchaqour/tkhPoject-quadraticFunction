# Structuring a function ax^2+bx+c
def getpolynomial(a=0,b=0,c=0):
  try:
    f=lambda x: a*x**2+b*x+c
    return f
  except:
    return "Check your input"
  
#Getting the image of x by f
def get_image(f,x):
  try:
    return f(x)
  except:
    return "Please check your function"